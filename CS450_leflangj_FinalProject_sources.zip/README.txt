+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

 Final Project for OSU's CS450/550: Intro to Computer Graphics
                         James Leflang

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

This project is intended to be compiled on a Windows machine with Visual Studio
    installed.

HDR "LA_Downtown_Helipad_GoldenHour_3k.hdr" found at https://polyhaven.com/hdris

Third Party Tools
-----------------

- GLM 0.9.9.8 (https://github.com/g-truc/glm/)
- FreeGLUT 3.0.0.0 MSVC (https://www.transmissionzero.co.uk/software/freeglut-devel/)
- GLEW 2.2.0 (https://github.com/nigels-com/glew)
- stb_image.h 2.27 (https://github.com/nothings/stb)

